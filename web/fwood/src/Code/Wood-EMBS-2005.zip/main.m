% Copyright October, 2005, Brown University, Providence, RI. 
% All Rights Reserved 

% Permission to use, copy, modify, and distribute this software and its
% documentation for any purpose other than its incorporation into a commercial
% product is hereby granted without fee, provided that the above copyright
% notice appear in all copies and that both that copyright notice and this
% permission notice appear in supporting documentation, and that the name of
% Brown University not be used in advertising or publicity pertaining to
% distribution of the software without specific, written prior permission. 

% BROWN UNIVERSITY DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE,
% INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR ANY
% PARTICULAR PURPOSE. IN NO EVENT SHALL BROWN UNIVERSITY BE LIABLE FOR ANY
% SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER
% RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF
% CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN
% CONNECTION WITH THE USE.

% Author: Frank Wood fwood@cs.brown.edu.

% script main

% these are the most important variables that affect run time and accuracy
% num_particles is the number of particles the particle filter uses to
% estimate the posterior distribution
num_particles = 500;
% history_bins_to_use is the number of bins of history to use in
% constructing the Fisher linear discriminant
history_bins_to_use = 10;
% this variable controls what happens when a "stop" or "not attending"
% state is detected.  set it to 0 to inject particles with x=0 y=0, 1 to 
% inject particles x = last decoded x, y = last decoded y
reset_style = 1;

% these are the data files used, training and test data are both specified
% here the data structure in each of these files is described next:

% it is assumed that both of these have "label (nx1)", "rate (nxk)" and "kin (nx2)"
% where n is number of timesteps and k is number of neurons
training_data = './data/training_data.mat';
test_data = './data/test_data.mat';
% 
% training_data = './data/LA030522MI-1400-2100sec-training.mat';
% test_data = './data/LA030522MI-1400-2100sec-test.mat';

disp('::main:: Inferring attention and kinematics from Motor Cortical Firing rates');
disp('::main:: Setting parameters');
disp(sprintf('::main:: num_particles = %d ', num_particles));
disp(sprintf('::main:: history_bins_to_use = %d ', history_bins_to_use));
disp(sprintf('::main:: reset_style = %d ', reset_style));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Prepare the training and test data............
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
disp(sprintf('::main:: Loading training_data data %s', training_data));
load(training_data);
disp(sprintf('::main:: Building history data structure with history (%d) from training data',history_bins_to_use));

training_rate = rate;%rate(1:1500,1:40);
training_kin = kin;%kin(1:1500,:);
training_label = label;%label(1:1500,:);
clear rate kin label;

% make the rate zero mean
training_rate_mean = mean(training_rate);
training_rate = training_rate-repmat(training_rate_mean,size(training_rate,1),1);
training_kin_mean = mean(training_kin);
training_kin = training_kin-repmat(training_kin_mean,size(training_kin,1),1);

[trimmed_label, rate_history_data_structure, trimmed_rate, trimmed_kin] = ...
    build_history_data_structure(training_label, training_rate, training_kin,history_bins_to_use);
clear training_rate training_kin training_label;
training_data = struct;
training_data.true_label = trimmed_label;
training_data.concat_rate = rate_history_data_structure;
training_data.rate = trimmed_rate;
training_data.kin = trimmed_kin;
clear trimmed_* rate_history_data_structure;
disp('::main:: Calculating Fisher Linear Discriminant from training data');
[w_opt,b, P_gamma_given_Z] = calculate_fisher_discriminant(training_data);

plot_fisher_projection(training_data,w_opt,b, P_gamma_given_Z,3)

disp('::main:: if figure 3 doesn''t show two clearly discernable humps')
disp('::main:: then either more history should be used, or the firing')
disp('::main:: history is insuffient to linearly separate the two states')
disp('::main:: and a more powerful classifier should be used')
drawnow

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
disp(sprintf('::main:: Loading test_data data %s',test_data));
load(test_data);
disp(sprintf('::main:: Building history data structure with history (%d) from test data', history_bins_to_use));

test_rate = rate;
test_kin = kin;
test_label = label;

test_rate = rate;%rate(1:500,1:40);
test_kin = kin;%kin(1:500,:);
test_label = label;%label(1:500,:);

clear rate kin label;

test_rate = test_rate-repmat(training_rate_mean,size(test_rate,1),1);
test_kin = test_kin-repmat(training_kin_mean,size(test_kin,1),1);

[trimmed_label, rate_history_data_structure, trimmed_rate, trimmed_kin] = ...
    build_history_data_structure(test_label, test_rate, test_kin, history_bins_to_use);

clear test_*;
test_data = struct;
test_data.true_label = trimmed_label;
test_data.concat_rate = rate_history_data_structure;
test_data.rate = trimmed_rate;
test_data.kin = trimmed_kin;
clear trimmed_* rate_history_data_structure;

% x' = Ax + w (state model)
% z'  = Hx + q (likelihood)
[H,Q, A,W] = linear_gaussian_least_squares_fit(training_data);
P_gamma = estimate_P_gamma(training_data);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data is ready, run the particle filter.....
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

disp('::main:: Running particle filter -- be patient, can be slow.  Esp. w/ many particles');
[kinematics_estimate, attentional_state_estimate, classifier_output] = ...
    particle_filter(test_data, num_particles, ...
    H,Q, A,W, w_opt, b, P_gamma, P_gamma_given_Z, ...
    history_bins_to_use, reset_style);

disp('::main:: Done filtering ... processing results');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Once we have the results; process to get some numbers/plots...
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% if you want unmodified metrics and journal style plots you can call this 
%[corr_x, corr_y, mse_x, mse_y, mse_xy] = compute_and_plot_decoding_accuracy(test_data.kin, kinematics_estimate, attentional_state_estimate, 1, classifier_output);

plot_start = 1;
plot_stop = size(kinematics_estimate,1);
show_plots = 1;

disp(sprintf('::main:: Switching particle filter results for range %d .. %d',plot_start,plot_stop));

calc = sign(classifier_output);
recons = kinematics_estimate;
original = test_data.kin;

[corr_x, corr_y, mse_x, mse_y, mse_xy] = ...
    modified_metric(recons, original, test_data.true_label, calc', plot_start, plot_stop);

plot_results_color(original, kinematics_estimate, attentional_state_estimate, ...
    classifier_output, ...
    plot_start, plot_stop);

disp('::main:: Modified Metric results are: ');
disp(sprintf('::main:: Corr coeff ( x=%f, y=%f )', corr_x, corr_y));
disp(sprintf('::main:: MSE ( x=%f, y=%f, x+y=%f ) ', mse_x, mse_y, mse_xy));



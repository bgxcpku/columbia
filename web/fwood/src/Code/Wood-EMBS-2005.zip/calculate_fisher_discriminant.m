% Copyright October, 2005, Brown University, Providence, RI. 
% All Rights Reserved 

% Permission to use, copy, modify, and distribute this software and its
% documentation for any purpose other than its incorporation into a commercial
% product is hereby granted without fee, provided that the above copyright
% notice appear in all copies and that both that copyright notice and this
% permission notice appear in supporting documentation, and that the name of
% Brown University not be used in advertising or publicity pertaining to
% distribution of the software without specific, written prior permission. 

% BROWN UNIVERSITY DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE,
% INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR ANY
% PARTICULAR PURPOSE. IN NO EVENT SHALL BROWN UNIVERSITY BE LIABLE FOR ANY
% SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER
% RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF
% CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN
% CONNECTION WITH THE USE.

% Author: Frank Wood fwood@cs.brown.edu.

%   function [w_opt,b] = calculate_fisher_discriminant(data)
%
% This function will calculate the Fisher discriminant direction "w"
% onto which the data points can be projected...

function [w_opt,b, P_gamma_given_Z] = calculate_fisher_discriminant(data)

% Convert to Hoffman's notation
Xplus_indices = find(data.true_label==1);
Xminus_indices = find(data.true_label==-1);

X_plus = data.concat_rate(Xplus_indices,:);
X_minus = data.concat_rate(Xminus_indices, :);

% The following is from Hoffma's lecture notes (Pg. 74) Matlab5 example

% number of positive and negative examples
num_plus = size(X_plus,1);
num_minus = size(X_minus,1);

% class means and difference of class means
m_plus = sum(X_plus, 1) / num_plus;
m_minus = sum(X_minus,1) / num_minus;
m_diff = m_plus - m_minus;

% subtract class mean from data
mX_plus = X_plus - repmat(m_plus, num_plus, 1);
mX_minus = X_minus - repmat(m_minus,num_minus,1);

% compute within class scatter
S_plus = mX_plus' * mX_plus ;
S_minus = mX_minus' * mX_minus ;
S = S_plus + S_minus ;

% optimal w
w_opt = inv(S) * m_diff';

S_plus_cov = S_plus/num_plus;
S_minus_cov = S_minus/num_minus;

stop_mean = m_plus*w_opt;
go_mean = m_minus*w_opt;

stop_cov = w_opt'*S_plus_cov*w_opt;
go_cov = w_opt'*S_minus_cov*w_opt;

% go_mean = m_plus*w_opt;
% stop_mean = m_minus*w_opt;
% 
% go_cov = w_opt'*S_plus_cov*w_opt;
% stop_cov = w_opt'*S_minus_cov*w_opt;

u1 = stop_mean;
u2 = go_mean;
alpha1 = num_plus/(num_plus+num_minus);
alpha2 = num_minus/(num_plus+num_minus);
s1 = sqrt(stop_cov);
s2 = sqrt(go_cov);

a = (s2^2-s1^2);
b = 2*((s1^2)*u2-(s2^2)*u1);
c = (s2^2)*(u1^2)-(s1^2)*(u2^2)-(s2^2)*(s1^2)*log(((alpha1^2)*(s2^2))/((alpha2^2)*(s1^2)));

x1 = (-b +sqrt(b^2-4*a*c))/(2*a);
x2 = (-b -sqrt(b^2-4*a*c))/(2*a);

if(u2<x2 & x2<u1)
    b = x2;
else
    b = x1;
end

P_gamma_given_Z = struct;
P_gamma_given_Z.stop_mean = stop_mean;
P_gamma_given_Z.stop_var = stop_cov;
P_gamma_given_Z.stop_alpha = num_plus/(num_plus+num_minus);

P_gamma_given_Z.go_mean = go_mean;
P_gamma_given_Z.go_var = go_cov;
P_gamma_given_Z.go_alpha = num_minus/(num_plus+num_minus);

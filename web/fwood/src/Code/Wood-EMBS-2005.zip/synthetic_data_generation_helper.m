% Copyright October, 2005, Brown University, Providence, RI. 
% All Rights Reserved 

% Permission to use, copy, modify, and distribute this software and its
% documentation for any purpose other than its incorporation into a commercial
% product is hereby granted without fee, provided that the above copyright
% notice appear in all copies and that both that copyright notice and this
% permission notice appear in supporting documentation, and that the name of
% Brown University not be used in advertising or publicity pertaining to
% distribution of the software without specific, written prior permission. 

% BROWN UNIVERSITY DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE,
% INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR ANY
% PARTICULAR PURPOSE. IN NO EVENT SHALL BROWN UNIVERSITY BE LIABLE FOR ANY
% SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER
% RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF
% CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN
% CONNECTION WITH THE USE.

% Author: Frank Wood fwood@cs.brown.edu.

function [label, kin, rate] = synthetic_data_generation_helper(length, num_cells, A, W, Hgo, Hstop, Qgo, Qstop)

label = zeros(length,1);
kin = zeros(length,2);
rate = zeros(length,num_cells);

boundary_end = round(rand*length/2);
current_label =-1;
boundary_start = 2;
kin(1,:) = [0 0];
rate(1,:) = mvnrnd(Hgo*kin(1,:)',Qgo);
while(boundary_end+1<length)
    label(boundary_start:boundary_end) = current_label;
    switch(current_label)
        case -1
            current_label = 1;
            for(i=boundary_start:boundary_end)
                label(i) = -1;
                kin(i,:) = mvnrnd(A*kin(i-1,:)',W);
                rate(i,:) = mvnrnd(Hgo*kin(i,:)',Qgo);
            end
        case 1
            current_label  = -1;
            for(i=boundary_start:boundary_end)
                label(i) = 1;
                kin(i,:) = kin(i-1,:);
                rate(i,:) = mvnrnd(zeros(size(rate(i,:))),Qstop);
            end
    end
    boundary_start = boundary_end+1;
    boundary_end = boundary_end+round(rand*length/2);

end

for(i=boundary_start:size(label,1))
    label(i) = -1;
    kin(i,:) = mvnrnd(A*kin(i-1,:)',W);
    rate(i,:) = mvnrnd(Hgo*kin(i-1,:)',Qgo);
end

% Copyright October, 2005, Brown University, Providence, RI. 
% All Rights Reserved 

% Permission to use, copy, modify, and distribute this software and its
% documentation for any purpose other than its incorporation into a commercial
% product is hereby granted without fee, provided that the above copyright
% notice appear in all copies and that both that copyright notice and this
% permission notice appear in supporting documentation, and that the name of
% Brown University not be used in advertising or publicity pertaining to
% distribution of the software without specific, written prior permission. 

% BROWN UNIVERSITY DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE,
% INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR ANY
% PARTICULAR PURPOSE. IN NO EVENT SHALL BROWN UNIVERSITY BE LIABLE FOR ANY
% SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER
% RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF
% CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN
% CONNECTION WITH THE USE.

% Author: Frank Wood fwood@cs.brown.edu.

% function P_gamma = estimate_P_gamma(training_data)
%   estimates marginal and conditional distributions
%   of attentional state from training data
%
%  The resulting data structures conform to the following
%  
% Not Attending = 1
% Attending = 2

function P_gamma = estimate_P_gamma(training_data)

% count the number of attending (go) and not attending (stop) states in the
% training data
l = training_data.true_label;
num_stop = length(find(l(2:end)==1));
num_go = length(find(l(2:end)==-1));
total = length(l)-1;
% compute the marginal probabilities
P_gamma.stop = num_stop/total;
P_gamma.go = num_go/total;

% count the conditional probability counts (transitions)
go_go_count=0;
go_stop_count=0;
stop_go_count=0;
stop_stop_count=0;

for(i=2:total)
    t = l(i)+l(i-1);
    switch(t)
        case {-2}
            go_go_count = go_go_count+1;
        case {0}
            if(l(i)==1)
                go_stop_count = go_stop_count+1;
            else
                stop_go_count = stop_go_count+1;
            end
        case {2}
            stop_stop_count = stop_stop_count+1;
    end
end

P_gamma.stop_stop = stop_stop_count/(total-1);
P_gamma.go_stop = go_stop_count/(total-1);
P_gamma.stop_go = stop_go_count/(total-1);
P_gamma.go_go = go_go_count/(total-1);

% Stop = 1
% Go = 2

P_gamma.cond = zeros(2);

%(gamma_i-1, gamma_i)
P_gamma.cond(1,1) = P_gamma.stop_stop;
P_gamma.cond(1,2) = P_gamma.stop_go;
P_gamma.cond(2,1) = P_gamma.go_stop;
P_gamma.cond(2,2) = P_gamma.go_go;
P_gamma.marg = zeros(2,1);
P_gamma.marg(1) = P_gamma.stop;
P_gamma.marg(2) = P_gamma.go;

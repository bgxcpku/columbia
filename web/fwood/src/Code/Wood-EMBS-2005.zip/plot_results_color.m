% Copyright October, 2005, Brown University, Providence, RI. 
% All Rights Reserved 

% Permission to use, copy, modify, and distribute this software and its
% documentation for any purpose other than its incorporation into a commercial
% product is hereby granted without fee, provided that the above copyright
% notice appear in all copies and that both that copyright notice and this
% permission notice appear in supporting documentation, and that the name of
% Brown University not be used in advertising or publicity pertaining to
% distribution of the software without specific, written prior permission. 

% BROWN UNIVERSITY DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE,
% INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR ANY
% PARTICULAR PURPOSE. IN NO EVENT SHALL BROWN UNIVERSITY BE LIABLE FOR ANY
% SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER
% RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF
% CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN
% CONNECTION WITH THE USE.

% Author: Frank Wood fwood@cs.brown.edu.


% utility function to take 
% the Original trajectory and the reconstructed trajectory

% - plot the graphs
% - output /return the MSE
% - output/return the corrcoeff

function plot_results_color(original, recons, switching_state, ...
                                            Perceptron_state, ...
                                            start_time, end_time) 

original_X = original(:,1);
original_Y = original(:,2);
recons_X = recons(:,1);
recons_Y = recons(:,2);

% show plots if the flag is set.. this is to disable plotting if you are
% varying parameters..
if (1)
    figure(1)
    %for i=start_time:end_time
    h1=plot(start_time:end_time, recons_X(start_time:end_time),'r');
    hold on
    h2=plot(start_time:end_time, original_X(start_time:end_time), 'b');
    

        h3=plot(start_time:end_time, 2*switching_state(start_time:end_time)-20,'k:');
        h4=plot_perceptron_state(Perceptron_state,start_time, end_time);
        legend([h1 h2 h3 h4], 'Estimated X','Real X','Estimated s/w state','Fisher Output');

%         h4=plot(start_time:end_time, 2*Perceptron_state(start_time:end_time)-15,'k-')
%         h4=plot(start_time:end_time, 5*switching_state(start_time:end_time)-15,'co')
%         legend([h1 h2 h3 h4], 'Estimated X','Real X','Estimated s/w state','Fisher Output');
%set(gca,'YTick',[])
%set(gca,'XTick',[])
set(gca,'Xlim',[start_time end_time])
    
    hold off
    set(gca,'Xlim',[start_time end_time])

    %end  
    figure(2)
    %for i=start_time:end_time
    h1=plot(start_time:end_time, recons_Y(start_time:end_time),'r');
    hold on
    h2=plot(start_time:end_time, original_Y(start_time:end_time), 'b');


        h3=plot(start_time:end_time, 2*switching_state(start_time:end_time)-20,'k:');
%         h4=plot(start_time:end_time, 2*Perceptron_state(start_time:end_time)-15,'k-')   
        h4=plot_perceptron_state(Perceptron_state,start_time, end_time);
        legend([h1 h2 h3 h4], 'Estimated Y','Real Y','Estimated s/w state','Fisher Output');

        %         h4=plot(start_time:end_time, 5*switching_state(start_time:end_time)-15,'co');
%legend([h1 h2 h3 h4],'Estimated Y','Real Y','Estimated s/w state','Fisher Output');
    
       
    hold off
    %set(gca,'YTick',[])
    %set(gca,'XTick',[])
    %set(gca,'Xlim',[start_time end_time])
    
    %end  
    
 
end

function h4 = plot_perceptron_state(Perceptron_state,start_time, end_time)

       cpi=1;
        ps_points(cpi,1) = start_time;
        ps_points(cpi,2) = 2*Perceptron_state(start_time)-15;
        cpi=2;
        for(i=start_time+1:end_time)
            if(Perceptron_state(i)~=Perceptron_state(i-1))
                ps_points(cpi,1) = i-.5;
                ps_points(cpi,2) = ps_points(cpi-1,2);
                cpi=cpi+1;
                ps_points(cpi,1) = i-.5;
                ps_points(cpi,2) = 2*Perceptron_state(i)-15;
                cpi=cpi+1;
            end
        end
        ps_points(cpi,1) = end_time;
        ps_points(cpi,2) = ps_points(cpi-1,2);
        h4=line(ps_points(:,1),ps_points(:,2));
        set(h4,'Color',[0 0 0])

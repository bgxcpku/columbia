% Copyright October, 2005, Brown University, Providence, RI. 
% All Rights Reserved 

% Permission to use, copy, modify, and distribute this software and its
% documentation for any purpose other than its incorporation into a commercial
% product is hereby granted without fee, provided that the above copyright
% notice appear in all copies and that both that copyright notice and this
% permission notice appear in supporting documentation, and that the name of
% Brown University not be used in advertising or publicity pertaining to
% distribution of the software without specific, written prior permission. 

% BROWN UNIVERSITY DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE,
% INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR ANY
% PARTICULAR PURPOSE. IN NO EVENT SHALL BROWN UNIVERSITY BE LIABLE FOR ANY
% SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER
% RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF
% CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN
% CONNECTION WITH THE USE.

% Author: Prabhat prabhat@cs.brown.edu.


% applying Michael/Frank's metric to the problem.. 
%
% label is the correct label
% calc is the calculated switching state
% use_switching is a flag for whether switching was used.. 
%

function [corr_x, corr_y, mse_x, mse_y, mse_xy] = ...
    modified_metric(recons, original, label, calc, start, stop)

label = label(start:stop);
calc  = calc(start:stop);

A = recons(:,1);
B = original(:,1);
A = A(start:stop);
B = B(start:stop);

corr_x = modified_correlation(A,B, label, calc);
mse_x = modified_mse(A,B, label, calc);

A = recons(:,2);
B = original(:,2); 
A = A(start:stop);
B = B(start:stop);

corr_y = modified_correlation(A,B, label, calc);
mse_y = modified_mse(A,B, label, calc);

mse_xy = mse_x + mse_y;

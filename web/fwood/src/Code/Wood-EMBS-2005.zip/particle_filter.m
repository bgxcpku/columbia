% Copyright October, 2005, Brown University, Providence, RI. 
% All Rights Reserved 

% Permission to use, copy, modify, and distribute this software and its
% documentation for any purpose other than its incorporation into a commercial
% product is hereby granted without fee, provided that the above copyright
% notice appear in all copies and that both that copyright notice and this
% permission notice appear in supporting documentation, and that the name of
% Brown University not be used in advertising or publicity pertaining to
% distribution of the software without specific, written prior permission. 

% BROWN UNIVERSITY DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE,
% INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR ANY
% PARTICULAR PURPOSE. IN NO EVENT SHALL BROWN UNIVERSITY BE LIABLE FOR ANY
% SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER
% RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF
% CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN
% CONNECTION WITH THE USE.

% Author: Frank Wood fwood@cs.brown.edu.

% function [kinematics_estimate, attentional_state_estimate, classifier_output] = ...
%     particle_filter(test_data, num_particles, ...
%     H,Q, A,W, w_opt, b, P_gamma, P_gamma_given_Z, ...
%     history_bins_to_use, display_data)

function [kinematics_estimate, attentional_state_estimate, classifier_output] = ...
    particle_filter(test_data, num_particles, ...
    H,Q, A,W, w_opt, b, P_gamma, P_gamma_given_Z, ...
    history_bins_to_use, reset_style)

disp(sprintf('::particle_filter:: being applied with %d particles', num_particles));

D=1;
rate = test_data.rate;
kin = test_data.kin;

kinematics_estimate = zeros(size(kin,1),size(kin,2));
attentional_state_estimate = zeros(size(kin,1),1);
classifier_output = zeros(size(attentional_state_estimate,1),1);

% parameters for particle filtering..
num_timesteps = size(kin,1);
state_particles = zeros(size(kin,2)+1, num_particles);
[state_elements, num_particles] = size(state_particles);
% state_particles is a 2 x num_particles array
start_time = 1;
zero_state = zeros(1, state_elements);
wn = mvnrnd(zero_state(1:end-1), 2*W, num_particles);

% randomly initialize state particles.  This could be different depending
% on experimental setup.  Should really transform kinematics to unit
% covariance

% this is an accepted cheat to start the decoder in approximately the
% correct initial state.
state_particles(1:end-1,:) = rand(size(state_particles(1:end-1,:)))*1+repmat(test_data.kin(1,:)',size(state_particles(1,:)));
state_particles(end,:) = round(rand(size(state_particles(end,:))));
state_particles(end,find(state_particles(end,:)==0))=-1;

weights = ones(1,num_particles)/num_particles;

% precompute the classifier output in one fell swoop
classifier_output = get_fisher_label(test_data.concat_rate, w_opt,b);


for t=start_time:num_timesteps
    current_firing_rate = test_data.concat_rate(t,:);

    xu = update_state(state_particles, A, W, P_gamma, weights, D, reset_style); %x' = Ax + w
    weights = update_importance_weights(xu, rate(t, :), H, Q, weights, P_gamma_given_Z,P_gamma,current_firing_rate, w_opt, b);

    kinematics_estimate(t,:) = weights*xu(1:end-1,:)';
    attentional_state_estimate(t) = weights*xu(end,:)';
    state_particles = resample(xu,weights,num_particles);

    weights = ones(1,num_particles)/num_particles;

    % print a progress bar
    if (mod(t-start_time,floor(num_timesteps/20))==0)
        disp(sprintf('::particle_filter:: done with %d/%d iterations',t,num_timesteps));
    end
end















% Copyright October, 2005, Brown University, Providence, RI. 
% All Rights Reserved 

% Permission to use, copy, modify, and distribute this software and its
% documentation for any purpose other than its incorporation into a commercial
% product is hereby granted without fee, provided that the above copyright
% notice appear in all copies and that both that copyright notice and this
% permission notice appear in supporting documentation, and that the name of
% Brown University not be used in advertising or publicity pertaining to
% distribution of the software without specific, written prior permission. 

% BROWN UNIVERSITY DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE,
% INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR ANY
% PARTICULAR PURPOSE. IN NO EVENT SHALL BROWN UNIVERSITY BE LIABLE FOR ANY
% SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER
% RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF
% CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN
% CONNECTION WITH THE USE.

% Author: Prabhat prabhat@cs.brown.edu.


% function implements correlation taking Michael/Frank's suggestion into
% account

% If monkey has stopped and calc is stopped, corr = 1
% If monkey has stopped and calc is moving,  corr = 0
% If monkey is moving, corr is as usual
% In the end, weight all these

function corr = modified_correlation(A, B, label, calc)

correct_stop = find((label==1)&(calc==1));
wrong_stop = find((label==1)&(calc==-1));

%working = find((label~=calc)|((label==-1)&(calc==-1)));
working = find(label==-1);

num_correct_stop = length(correct_stop);
num_wrong_stop = length(wrong_stop);
num_working = length(working);

A_correct_stop    = A(correct_stop);
A_wrong_stop = A(wrong_stop);
A_working = A(working);

B_correct_stop    = B(correct_stop);
B_wrong_stop = B(wrong_stop);
B_working = B(working);

cc = corrcoef(A_working, B_working);
cc = cc(1,2);

corr = (cc*num_working + 1*num_correct_stop + 0*num_wrong_stop) / ...
    (num_working + num_correct_stop + num_wrong_stop);

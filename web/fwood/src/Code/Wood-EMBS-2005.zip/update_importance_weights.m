% Copyright October, 2005, Brown University, Providence, RI. 
% All Rights Reserved 

% Permission to use, copy, modify, and distribute this software and its
% documentation for any purpose other than its incorporation into a commercial
% product is hereby granted without fee, provided that the above copyright
% notice appear in all copies and that both that copyright notice and this
% permission notice appear in supporting documentation, and that the name of
% Brown University not be used in advertising or publicity pertaining to
% distribution of the software without specific, written prior permission. 

% BROWN UNIVERSITY DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE,
% INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR ANY
% PARTICULAR PURPOSE. IN NO EVENT SHALL BROWN UNIVERSITY BE LIABLE FOR ANY
% SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER
% RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF
% CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN
% CONNECTION WITH THE USE.

% Author: Frank Wood fwood@cs.brown.edu.


function q = update_importance_weights(xu, z, H, Q,oldq, P_gamma_given_Z, P_gamma, concat_rate,w_opt,b);
% PURPOSE : Computes the normalized importance ratios
% INPUTS  : - xu = The predicted state samples
%                   #state variables X #particles array
%           - z =  The observed measurements
%           - Q = The measurement noise covariance.
%           - H = noise model parameter (z = Hx + q)
% OUTPUTS : - q = The normalised importance ratios.

N = length(xu(1,:));
w_t = log(oldq) + fvnlp((repmat(z',1,N) -H * xu(1:end-1,:)),zeros(length(z(1,:)),1),Q);
gamma_i = xu(end,:);

gamma_i(find(gamma_i==-1))=2;

p_gamma_i = log(P_gamma.marg(gamma_i));

p_gamma_given_z = zeros(size(p_gamma_i));
for(i=1:length(p_gamma_given_z))
    p_gamma_given_z(i) = eval_P_gamma_given_Z(P_gamma_given_Z,xu(end,i),concat_rate, ...
        w_opt, b);
end

w_t = exp((w_t+p_gamma_given_z')-p_gamma_i');

w_t_sum = sum(w_t);
if(w_t_sum==0)
    w_t = repmat(1/N,1,N);
else
    w_t = w_t/sum(w_t);
end
q = w_t;


% N = length(xu(1,:));
% w_t = oldq .*fvnp((repmat(z',1,N) -H * xu(1:end-1,:)),zeros(length(z(1,:)),1),Q);
% gamma_i = xu(end,:);
% 
% gamma_i(find(gamma_i==-1))=2;
% 
% p_gamma_i = P_gamma.marg(gamma_i);
% 
% p_gamma_given_z = zeros(size(p_gamma_i));
% for(i=1:length(p_gamma_given_z))
%     p_gamma_given_z(i) = eval_P_gamma_given_Z(P_gamma_given_Z,xu(end,i),concat_rate, ...
%         w_opt, b);
% end
% 
% w_t = (w_t.*p_gamma_given_z')./p_gamma_i';
% 
% w_t_sum = sum(w_t);
% if(w_t_sum==0)
%     w_t = repmat(1/N,1,N);
% else
%     w_t = w_t/sum(w_t);
% end
% q = w_t;

% Copyright October, 2005, Brown University, Providence, RI. 
% All Rights Reserved 

% Permission to use, copy, modify, and distribute this software and its
% documentation for any purpose other than its incorporation into a commercial
% product is hereby granted without fee, provided that the above copyright
% notice appear in all copies and that both that copyright notice and this
% permission notice appear in supporting documentation, and that the name of
% Brown University not be used in advertising or publicity pertaining to
% distribution of the software without specific, written prior permission. 

% BROWN UNIVERSITY DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE,
% INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR ANY
% PARTICULAR PURPOSE. IN NO EVENT SHALL BROWN UNIVERSITY BE LIABLE FOR ANY
% SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER
% RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF
% CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN
% CONNECTION WITH THE USE.

% Author: Frank Wood fwood@cs.brown.edu.

% create_synthetic_data
rand('state',13);
randn('state',13);
training_data_length = 2000;
test_data_length = 500;
num_cells = 2;

A = eye(2,2);
Hgo = zeros(num_cells,2)+20;
Hstop = zeros(num_cells,2)-20;
W = [.5 .1; .1 .5];
Qgo = eye(num_cells)*.1;%gallery('randcorr',num_cells)*1e-50;
Qstop = eye(num_cells)*.2;%gallery('randcorr',num_cells)*1e-50;

[label, kin, rate] = synthetic_data_generation_helper(training_data_length, num_cells, A, W, Hgo, Hstop, Qgo, Qstop);
mkin = mean(kin);
kin = kin - repmat(mkin,size(kin,1),1);
save './data/training_data.mat' kin rate label

[label, kin, rate] = synthetic_data_generation_helper(test_data_length, num_cells, A, W, Hgo, Hstop, Qgo, Qstop);
kin = kin - repmat(mkin,size(kin,1),1);
save './data/test_data.mat' kin rate label




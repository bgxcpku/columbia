% Copyright October, 2005, Brown University, Providence, RI. 
% All Rights Reserved 

% Permission to use, copy, modify, and distribute this software and its
% documentation for any purpose other than its incorporation into a commercial
% product is hereby granted without fee, provided that the above copyright
% notice appear in all copies and that both that copyright notice and this
% permission notice appear in supporting documentation, and that the name of
% Brown University not be used in advertising or publicity pertaining to
% distribution of the software without specific, written prior permission. 

% BROWN UNIVERSITY DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE,
% INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR ANY
% PARTICULAR PURPOSE. IN NO EVENT SHALL BROWN UNIVERSITY BE LIABLE FOR ANY
% SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER
% RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF
% CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN
% CONNECTION WITH THE USE.

% Author: Frank Wood fwood@cs.brown.edu.

The files contained herein pertain to neural decoding -- particularly
simultaneous kinematic and attentional state decoding from a single population
of neurons.  This code, however, implements a general decoding algorithm and is
capable of decoding any markov process with a multivariate continuous and
binary discrete state given a single noisy continuous observation that provides
information about both. (with the caveat that the observation model is
approximately linear gaussian and the binary state can be fairly well
classified using a linear classifier on the observation).

-- Acknowledgements --

Michael Black -- advisor
Prabhat -- co-author and initial implementer
John Donoghue -- neuroscience lab PI
Matthew Fellows -- neural data
Mijail  Serruya -- neural data

This work was supported by NIH-NINDS R01 NS 50967-01 as part of the
NSF/NIH Collaborative Research in Computational Neuroscience Program.


-- Requirements --

Tested on: 7.1.0.246 (R14) Service Pack 3 w/ stats package
Lot's of memory for neural data (min 1gb)
Fast processor

-- Usage --

Everything is set up to get started with synthetic data.  Load matlab, cd into 
this directory and type "main".  This will load synthetic data, train models, 
and run the particle filter.  It will produce 3 plots (in figures 1,2,3).  One
each for x and y decoding performance and one showing the performance of the 
fisher discriminant.  The initial example is intentionally noisy.  We experience
better performance with neural data.

-- Important Files --

main.m: The main script that loads data; trains classifiers, state, and
observation models; and decodes using a particle filter.  Plots and performance
results are also generated here.

generate_synthetic_data.m: a script to generate data of the format the decoder
requires.  modifying the values in this script will give a good sense of the
sensativity of the algorithm and how to adjust certain parameters in main.m.

Good luck!

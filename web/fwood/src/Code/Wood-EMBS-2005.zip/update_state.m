% Copyright October, 2005, Brown University, Providence, RI. 
% All Rights Reserved 

% Permission to use, copy, modify, and distribute this software and its
% documentation for any purpose other than its incorporation into a commercial
% product is hereby granted without fee, provided that the above copyright
% notice appear in all copies and that both that copyright notice and this
% permission notice appear in supporting documentation, and that the name of
% Brown University not be used in advertising or publicity pertaining to
% distribution of the software without specific, written prior permission. 

% BROWN UNIVERSITY DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE,
% INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR ANY
% PARTICULAR PURPOSE. IN NO EVENT SHALL BROWN UNIVERSITY BE LIABLE FOR ANY
% SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER
% RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF
% CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN
% CONNECTION WITH THE USE.

% Author: Frank Wood fwood@cs.brown.edu.

function xu = update_state( x , A, W, P_gamma,q, D, reset_style);
% function xu = update_state( x , A, W, P_gamma,q, D);
% PURPOSE : Performs the prediction step 
%
% INPUTS  : - x = The state samples (this is a 2 (state variables) X #particles array).
%           - t = The current time step.
%           - W = Covariance matrix of the process noise

% OUTPUTS : - xu = The state samples after the prediction step.

if nargin < 3, error('Not enough input arguments.'); end

[state_elements, num_particles] = size(x);
zero_state = zeros(1, state_elements);
w = mvnrnd(zero_state(1:end-1), W, num_particles); % ~N(0,W)

w = w'; % transpose since we need column order state

nsst = x(end,:);
nsst(find(nsst==-1))=2;

% x is 1 and 2 now (appropriately)
gamma_i_1 = nsst;
gamma_i = gamma_i_1 ;

stop_gamma_1 = find(gamma_i_1==1); % state at t-1 is stop
go_gamma_1 = find(gamma_i_1==2);   % 

%switch_indexes = find(rand(size(stop_gamma_1))>P_gamma.cond(1,1)); % BUG

switch_indexes = find(rand(size(stop_gamma_1))<P_gamma.cond(1,2));
gamma_i(stop_gamma_1(switch_indexes))=2; % Transiting from 1 to 2


%switch_indexes = find(rand(size(go_gamma_1))>P_gamma.cond(2,2)); % BUG

switch_indexes = find(rand(size(go_gamma_1))<P_gamma.cond(2,1));
gamma_i(go_gamma_1(switch_indexes))=1; % Transit from 2 to 1

%gamma_i is picked

%x = x + repmat(x_mean', 1, num_particles);
% x' = Ax + w
xu = x;
gamma_i(find(gamma_i==2))=-1;

xu(end,:) = gamma_i;
xu(1:end-1,go_gamma_1) = A * x(1:end-1,go_gamma_1) + w(:,go_gamma_1); % column order

% This is where the choice of what to decode when the monkey is not
% attending is made.

% xu(1:end-1,stop_gamma_1) =  ones(size(x(1:end-1,stop_gamma_1))).*repmat(ex,1,length(stop_gamma_1));%rand(size(x(1:end-1,stop_gamma_1)))*40-20;%x(1:end-1,stop_gamma_1) + randn(size(x(1:end-1,stop_gamma_1)))*D;
switch(reset_style)
    case 0
        xu(1:end-1,stop_gamma_1) =  zeros(size(x(1:end-1,stop_gamma_1)));
    case 1
        xu(1:end-1,stop_gamma_1) =  repmat((q*x(1:end-1,:)')',1,length(stop_gamma_1));
    otherwise
        error('Unknown reset style, only 0 and 1 implemented')
end


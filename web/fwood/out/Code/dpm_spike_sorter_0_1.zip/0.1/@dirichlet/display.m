function s = display(g)
% DIRICHLET/DISPLAY   
% DISPLAY() is the string representation of 

% Author: Frank Wood fwood@gatsby.ucl.ac.uk

% char(g)
s = char(g);
disp(s)

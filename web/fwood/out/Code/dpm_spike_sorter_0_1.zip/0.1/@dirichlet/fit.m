function g = fit(d,rate)
% DIRICHLET/FIT  Fit DIRICHLET model to that of data.  Data expected
% in datum per row format

% Author: Frank Wood fwood@gatsby.ucl.ac.uk


error('Dirichlet distribution fit procedure not implemented')
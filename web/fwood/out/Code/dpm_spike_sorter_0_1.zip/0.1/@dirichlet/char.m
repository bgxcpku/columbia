function s = char(g)
% DIRICHLET/CHAR   
% CHAR(p) is the string representation

% Author: Frank Wood fwood@gatsby.ucl.ac.uk


    s = [ 'DIRICHLET: alpha: ' mat2str(g.alpha) ];


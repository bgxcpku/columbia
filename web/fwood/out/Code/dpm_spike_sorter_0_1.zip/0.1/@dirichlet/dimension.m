function d = dimension(g)
% POISSON\DIMENSION dimension of lnp model

error('Semantics of poisson dimension ambiguous')

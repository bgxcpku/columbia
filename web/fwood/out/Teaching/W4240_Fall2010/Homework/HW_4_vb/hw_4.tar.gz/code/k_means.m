function assignments = k_means(k,data)
% The number of iterations is not a parameter here because it is not the
% focus of the assignment so just hard code it to something, maybe 10
%
%@param k       : the number of clusters
%@param data    : n x d data matrix
%
%@return        : n x 1 matrix of assignments in 1 : k
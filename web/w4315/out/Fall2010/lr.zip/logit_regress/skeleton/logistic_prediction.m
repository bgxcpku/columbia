function out = logistic_prediction(X,beta)

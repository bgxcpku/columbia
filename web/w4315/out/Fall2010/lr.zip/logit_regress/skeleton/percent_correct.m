function answer = percent_correct(y,y_hat)

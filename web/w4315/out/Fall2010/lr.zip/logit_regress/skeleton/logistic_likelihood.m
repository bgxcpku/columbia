function log_lik = logistic_likelihood(X,y,beta)
